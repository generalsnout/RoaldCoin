#!/bin/bash

TOPDIR=${TOPDIR:-$(git rev-parse --show-toplevel)}
SRCDIR=${SRCDIR:-$TOPDIR/src}
MANDIR=${MANDIR:-$TOPDIR/doc/man}

ROALDCOIND=${ROALDCOIND:-$SRCDIR/roaldcoind}
ROALDCOINCLI=${ROALDCOINCLI:-$SRCDIR/roaldcoin-cli}
ROALDCOINTX=${ROALDCOINTX:-$SRCDIR/roaldcoin-tx}
ROALDCOINQT=${ROALDCOINQT:-$SRCDIR/qt/roaldcoin-qt}

[ ! -x $ROALDCOIND ] && echo "$ROALDCOIND not found or not executable." && exit 1

# The autodetected version git tag can screw up manpage output a little bit
ROALDVER=($($ROALDCOINCLI --version | head -n1 | awk -F'[ -]' '{ print $6, $7 }'))

# Create a footer file with copyright content.
# This gets autodetected fine for bitcoind if --version-string is not set,
# but has different outcomes for bitcoin-qt and bitcoin-cli.
echo "[COPYRIGHT]" > footer.h2m
$ROALDCOIND --version | sed -n '1!p' >> footer.h2m

for cmd in $ROALDCOIND $ROALDCOINCLI $ROALDCOINTX $ROALDCOINQT; do
  cmdname="${cmd##*/}"
  help2man -N --version-string=${ROALDVER[0]} --include=footer.h2m -o ${MANDIR}/${cmdname}.1 ${cmd}
  sed -i "s/\\\-${ROALDVER[1]}//g" ${MANDIR}/${cmdname}.1
done

rm -f footer.h2m
